<template>
	
<view>
	<view>
		<button @click="initialBluetooth">初始化蓝牙</button>
	</view>
	
</view>	
</template>

<script>
	
	function initialBluetooth(){   
		uni.openBluetoothAdapter({
			success(res) {
				console.log('初始化蓝牙成功')
				console.log('初始化蓝牙返回信息：' + res)
			},
			fail(err){
				console.log('初始化蓝牙失败')
				console.log('初始化蓝牙失败报错信息：'+err)
				}		
		})
	}

	// function seekDevice(){   
		
		
	// }
	
	// function linkDevice(){	
		
	// }
	
	// function monitorDevice(){	
		
	// }
	
	// function sendDataDevice(){    
		
		
	// }
</script>

<style>
</style>