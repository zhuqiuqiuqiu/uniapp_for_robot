<template>
  <view class="box">
	  <br />
	  <view>
		<button class="button_setting" @click="goBluetooth">蓝牙连接</button>
	  </view>
	  <br />
	  <view>
		<button class="button_setting">WIFI连接</button>
	  </view>
	  <br />
	  <view>
		<button class="button_setting">账号管理</button>
	  </view>
	  <br />
	  <view>
		<button class="button_setting">关于我们</button>
	  </view>
  </view>
</template>


<script>
    export default {
      methods: {
        goBluetooth() {
          uni.navigateTo({
            url: '/Component/bluetooth'
          })
        }

      }
    }

</script>



<style>
.box {
  display: flex;
  flex-direction: column; 
  align-items: center;
  height: 80vh;
}
.button_setting{
	height: 50px;
	width: 	200px;
}


</style>