<template>
	<view id="container">
	
	<view class="pictures">
		<image src="" mode="aspectFill" id="picture1"></image>
		<image src="" mode="aspectFill" id="picture2"></image>
		<image src="" mode="aspectFill" id="picture3"></image>
	
	</view>
	
			
		<view class="swipe">

			<text style="color: white;">Swipe to start</text>
		</view>
	
	</view>
</template>

<script>
</script>

<style>
	page{background-color: #333;}
	.pictures{
		position:relative;
		width:100%;
		height:40vh;
		display:flex;
		justify-content:center;
		align-items:center;
	}

	#picture2{
		width:22vh;
		height:36vh;
		border-radius:30px;
		background:yellowgreen;
		z-index:2;
		margin-top: -5vh;
	}

	#picture1{
		position:absolute;
		width:24vh;
		height:36vh;
		border-radius:30px;
		background:aqua;
		transform:translateX(-100%);
	}

	#picture3{
		position:absolute;
		width:24vh;
		height:36vh;
		border-radius:30px;
		background:orange;
		transform:translateX(100%);
	}

	.swipe{
		border: 2px solid #696969;
		border-radius: 40px;
		width:25vh;
		height: 6vh;
		text-align:center;
		display: flex;
		align-items: center;
		justify-content: center;
		background-color:#696969;
		margin: 40vh auto;	
	}

</style>